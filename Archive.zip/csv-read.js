import fs from "fs";
import path from "path";
import csv from "fast-csv";

const __dirname = path.resolve();

function getCSVData(fileName) {
  return new Promise((resolve, reject) => {
    let dataArray = [];
    fs.createReadStream(
      path.resolve(__dirname, "files", fileName) //"719988-723576AddressTransaction.csv"
    )
      .pipe(csv.parse({ headers: true }))
      .on("error", (error) => console.error(error))
      .on("data", (row) => {
        dataArray.push(row);
        // console.log(row)
      })
      .on("end", (rowCount) => {
        console.log(`Parsed ${rowCount} rows`);
        resolve(dataArray);
      });
  });
}

// getCSVData().then(res=>{
//     console.log(res.length);
// })

export default getCSVData;
