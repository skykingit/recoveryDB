import mysql from 'mysql'
import Config from "./config.js"
import getCSVData from './csv-read.js';
import log4js from "log4js";

log4js.configure({
  appenders: { cheese: { type: "file", filename: "./logs/cheese.log" } },
  categories: { default: { appenders: ["cheese"], level: "all" } }
});

const logger = log4js.getLogger("cheese");

var connection = mysql.createConnection({
  host     : Config.host,
  user     : Config.user,
  password : Config.password,
  database : Config.db
});
 
connection.connect();
 
function query(sql,args){
    return new Promise((resolve,reject)=>{
        connection.query(sql,[args], (error, results, fields) => {
            if (error){
                reject(error);
            }else{
                logger.info(results);
                resolve(results);
            }
          });
    })

}
const start = 0;
const insertNum = 20;

function createArgs(lists,start){
    let r = [];
    let end = start + insertNum;
    if(end > lists.length){
        end = lists.length;
    }
    for(let i=start;i< end;i++){
        let current = lists[i];
        let itemArray = [];
        itemArray.push(current.address);
        itemArray.push(current.transaction_hash);
        itemArray.push(current.block_height);
        itemArray.push(current.amount);
        itemArray.push(current.eth_is_sender);
        r.push(itemArray);
    }
    return r;
}

function circleInserts(lists,start,end,sql){
    return new Promise((resolve,reject)=>{
        let args = createArgs(lists,start);
        query(sql,args).then(r=>{
            console.log(start,r);
            logger.info(start,r);
            if(start + insertNum < end){
                circleInserts(lists,start+insertNum,end,sql);
            }else{
                console.log("success----------");
                logger.info("success----------");
                resolve({
                    data:"success"
                })
            }
        }).catch(e=>{
            console.error(e);
            logger.error(e);
            reject(e);
        });
    })
}
let sql = "insert ignore into AddressTransaction values ?"
getCSVData("719988-723576AddressTransaction.csv").then(lists=>{
    const dbList = lists;
    const end = lists.length;
    return circleInserts(lists,0,end,sql);
}).then(r=>{
    console.log(r);
    logger.info(r);
    connection.end();
    process.exit(0);
}).catch(e=>{
    console.error(e);
    logger.error(e);
});
