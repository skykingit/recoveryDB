import mysql from 'mysql'
import Config from "./config.js"
var connection = mysql.createConnection({
  host     : Config.host,
  user     : Config.user,
  password : Config.password,
  database : Config.db
});
 
connection.connect();

let sql = "insert into AddressTransaction values ?"
let values = [
    ["bc1pzyvf022gwhy244emmfqlpp0zvlkjwfegl0sul6v49c344hqyvstsx258pg","bd60b271fb5c484a2cc054a5ee1ef3cd76bab22f4e2639280ad17b91b3bac07e","722780","41082750","0"]
]
 
connection.query(sql,[values], function (error, results, fields) {
  if (error) throw error;
  console.log('The solution is: ', results);
});
 
connection.end();