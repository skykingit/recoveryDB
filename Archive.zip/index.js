import mysql from 'mysql'
import Config from "./config.js"
var connection = mysql.createConnection({
  host     : Config.host,
  user     : Config.user,
  password : Config.password,
  database : Config.db
});
 
connection.connect();
 
connection.query('SELECT * FROM Block order by height desc LIMIT 0, 10', function (error, results, fields) {
  if (error) throw error;
  console.log('The solution is: ', results);
});
 
connection.end();